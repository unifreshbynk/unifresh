import "dotenv/config";
import express from "express";
import nodemailer from "nodemailer";
import crypto from "crypto";

const app = express();
const PORT = Number(process.env.MAIL_SERVER_PORT || 8787);
app.use(express.json({ limit: "1mb" }));
const pendingConfirmations = new Map();
const pendingLoginConfirmations = new Map();

function createTransporter() {
  const host = String(process.env.SMTP_HOST || "").trim();
  const user = String(process.env.SMTP_USER || "").trim();
  const pass = String(process.env.SMTP_PASS || "").trim().replace(/\s+/g, "");
  const port = Number(process.env.SMTP_PORT || 587);
  const secure = String(process.env.SMTP_SECURE || "false") === "true";

  if (!host || !user || !pass) {
    throw new Error("SMTP_HOST, SMTP_USER et SMTP_PASS sont obligatoires.");
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
  });
}

function buildSenderAddress() {
  const smtpUser = String(process.env.SMTP_USER || "").trim();
  const configuredFrom = String(process.env.MAIL_FROM || "").trim();
  // For best deliverability, keep "from" aligned with authenticated SMTP identity.
  return configuredFrom && configuredFrom.includes(smtpUser)
    ? configuredFrom
    : `UniFresh <${smtpUser}>`;
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/** Message lisible pour l'interface (sans dump technique SMTP). */
function formatSmtpError(error) {
  const raw = error instanceof Error ? error.message : String(error || "");
  if (/535|BadCredentials|Username and Password not accepted/i.test(raw)) {
    const user = String(process.env.SMTP_USER || "").trim() || "votre compte Gmail";
    return (
      `Connexion Gmail refusée pour ${user}. ` +
      "Créez un mot de passe d'application Google (compte → Sécurité → Validation en 2 étapes → Mots de passe des applications), " +
      "collez-le dans SMTP_PASS du fichier .env, puis relancez npm run server."
    );
  }
  if (/EAUTH|authentication/i.test(raw)) {
    return "Authentification SMTP échouée. Vérifiez SMTP_USER et SMTP_PASS dans .env.";
  }
  return raw || "Erreur serveur";
}

app.post("/api/register/send-code", async (req, res) => {
  try {
    const { email, prenom, nom, profilType, telephone, age, canton, ecole } = req.body || {};
    const cleanEmail = String(email || "").trim().toLowerCase();
    if (!cleanEmail) return res.status(400).json({ error: "Email requis." });

    const sender = buildSenderAddress();
    const replyTo = String(process.env.SMTP_USER || "").trim();
    const profileLabel =
      profilType === "entreprise" ? "Entreprise" : profilType === "particulier" ? "Particulier" : "Etudiant·e";
    const transporter = createTransporter();
    const code = String(crypto.randomInt(100000, 1000000));
    const expiresAt = Date.now() + 10 * 60 * 1000;
    pendingConfirmations.set(cleanEmail, { code, expiresAt });

    await transporter.sendMail({
      from: sender,
      replyTo,
      to: cleanEmail,
      subject: "Code de confirmation UniFresh",
      text: [
        "Bonjour,",
        "",
        "Merci pour votre inscription sur UniFresh.",
        "",
        `Voici votre code de confirmation : ${code}`,
        "",
        "Ce code est valable pendant 10 minutes.",
        "",
        "Veuillez saisir ce code dans le formulaire de confirmation afin de finaliser votre inscription.",
        "",
        "Recapitulatif de votre inscription",
        "",
        `Profil: ${profileLabel}`,
        telephone ? `Telephone: ${telephone}` : "",
        age != null ? `Age: ${age}` : "",
        canton ? `Canton: ${canton}` : "",
        ecole ? `Etablissement: ${ecole}` : "",
        "",
        "Vous recevez cet e-mail car une inscription a ete effectuee avec cette adresse e-mail. Si vous n'etes pas a l'origine de cette demande, aucune action n'est necessaire.",
        "",
        "Notre equipe vous contactera prochainement.",
        "",
        "Cordialement,",
        "",
        "L'equipe UniFresh",
      ]
        .filter(Boolean)
        .join("\n"),
      html: `
        <p>Bonjour,</p>
        <p>Merci pour votre inscription sur UniFresh.</p>
        <p>Voici votre code de confirmation : <strong>${escapeHtml(code)}</strong></p>
        <p>Ce code est valable pendant <strong>10 minutes</strong>.</p>
        <p>Veuillez saisir ce code dans le formulaire de confirmation afin de finaliser votre inscription.</p>
        <p><strong>Récapitulatif de votre inscription</strong></p>
        <ul>
          <li><strong>Profil :</strong> ${escapeHtml(profileLabel)}</li>
          ${telephone ? `<li><strong>Téléphone :</strong> ${escapeHtml(telephone)}</li>` : ""}
          ${age != null ? `<li><strong>Âge :</strong> ${escapeHtml(age)}</li>` : ""}
          ${canton ? `<li><strong>Canton :</strong> ${escapeHtml(canton)}</li>` : ""}
          ${ecole ? `<li><strong>Établissement :</strong> ${escapeHtml(ecole)}</li>` : ""}
        </ul>
        <p>Vous recevez cet e-mail car une inscription a été effectuée avec cette adresse e-mail. Si vous n’êtes pas à l’origine de cette demande, aucune action n’est nécessaire.</p>
        <p>Notre équipe vous contactera prochainement.</p>
        <p>Cordialement,</p>
        <p><strong>L’équipe UniFresh</strong></p>
      `,
    });

    return res.json({ ok: true, expiresInSeconds: 600 });
  } catch (error) {
    console.error("[SMTP] register/send-code:", error);
    return res.status(500).json({ error: formatSmtpError(error) });
  }
});

app.post("/api/register/verify-code", (req, res) => {
  const { email, code } = req.body || {};
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanCode = String(code || "").trim();
  if (!cleanEmail || !cleanCode) {
    return res.status(400).json({ error: "Email et code requis." });
  }

  const pending = pendingConfirmations.get(cleanEmail);
  if (!pending) {
    return res.status(404).json({ error: "Aucun code en attente pour cet e-mail." });
  }
  if (Date.now() > pending.expiresAt) {
    pendingConfirmations.delete(cleanEmail);
    return res.status(410).json({ error: "Code expiré. Demandez un nouveau code." });
  }
  if (pending.code !== cleanCode) {
    return res.status(401).json({ error: "Code invalide." });
  }

  pendingConfirmations.delete(cleanEmail);
  return res.json({ ok: true });
});

app.post("/api/login/send-code", async (req, res) => {
  try {
    const { email } = req.body || {};
    const cleanEmail = String(email || "").trim().toLowerCase();
    if (!cleanEmail) return res.status(400).json({ error: "Email requis." });

    const sender = buildSenderAddress();
    const replyTo = String(process.env.SMTP_USER || "").trim();
    const transporter = createTransporter();
    const code = String(crypto.randomInt(100000, 1000000));
    const expiresAt = Date.now() + 10 * 60 * 1000;
    pendingLoginConfirmations.set(cleanEmail, { code, expiresAt });

    await transporter.sendMail({
      from: sender,
      replyTo,
      to: cleanEmail,
      subject: "Code de connexion UniFresh",
      text: [
        "Bonjour,",
        "",
        "Voici votre code de connexion UniFresh :",
        code,
        "",
        "Ce code est valable pendant 10 minutes.",
        "",
        "Si vous n'etes pas a l'origine de cette demande, ignorez cet e-mail.",
      ].join("\n"),
      html: `
        <p>Bonjour,</p>
        <p>Voici votre code de connexion UniFresh :</p>
        <p><strong style="font-size:20px;letter-spacing:1px;">${escapeHtml(code)}</strong></p>
        <p>Ce code est valable pendant <strong>10 minutes</strong>.</p>
        <p>Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>
      `,
    });

    return res.json({ ok: true, expiresInSeconds: 600 });
  } catch (error) {
    console.error("[SMTP] login/send-code:", error);
    return res.status(500).json({ error: formatSmtpError(error) });
  }
});

app.post("/api/login/verify-code", (req, res) => {
  const { email, code } = req.body || {};
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanCode = String(code || "").trim();
  if (!cleanEmail || !cleanCode) {
    return res.status(400).json({ error: "Email et code requis." });
  }

  const pending = pendingLoginConfirmations.get(cleanEmail);
  if (!pending) {
    return res.status(404).json({ error: "Aucun code en attente pour cet e-mail." });
  }
  if (Date.now() > pending.expiresAt) {
    pendingLoginConfirmations.delete(cleanEmail);
    return res.status(410).json({ error: "Code expiré. Demandez un nouveau code." });
  }
  if (pending.code !== cleanCode) {
    return res.status(401).json({ error: "Code invalide." });
  }

  pendingLoginConfirmations.delete(cleanEmail);
  return res.json({ ok: true });
});

// POST /api/admin/verify-code — vérifier code admin (secret uniquement côté serveur)
app.post("/api/admin/verify-code", (req, res) => {
  const { code } = req.body || {};
  const adminCode = String(process.env.ADMIN_CODE || "").trim();

  if (!code) {
    return res.status(400).json({ success: false, message: "Code requis" });
  }
  if (!adminCode) {
    return res.status(500).json({ success: false, message: "ADMIN_CODE non configuré sur le serveur." });
  }

  const cleanCode = String(code).trim();
  if (cleanCode === adminCode) {
    const token = `admin_${crypto.randomBytes(12).toString("hex")}`;
    const expiryMs = Number(process.env.ADMIN_TOKEN_EXPIRY || 3600000);
    const expiresAt = Date.now() + (Number.isFinite(expiryMs) ? expiryMs : 3600000);

    console.log("[ADMIN] Code correct — token émis:", `${token.slice(0, 10)}...`);

    return res.json({
      success: true,
      token,
      expiresAt,
    });
  }

  console.log("[ADMIN] Code incorrect");
  return res.status(401).json({
    success: false,
    message: "Code admin invalide",
  });
});

app.listen(PORT, () => {
  console.log(`UniFresh mail server running on http://localhost:${PORT}`);
  const user = String(process.env.SMTP_USER || "").trim();
  if (user) {
    createTransporter()
      .verify()
      .then(() => console.log(`[SMTP] Connexion OK pour ${user}`))
      .catch((err) => {
        console.error(`[SMTP] Échec connexion pour ${user}:`, formatSmtpError(err));
      });
  }
});
