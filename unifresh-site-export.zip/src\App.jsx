import { useState, useMemo, useCallback, useEffect } from "react";
import {
  loadUser,
  saveUser,
  clearUser,
  loadSessionEmail,
  saveSessionEmail,
  clearSessionEmail,
  saveServiceWeeks,
  saveServiceRecurringTags,
  saveEntrepriseSlotMode,
  loadServiceDetail,
  loadServiceWeeks,
  loadServiceRecurringTags,
  loadEntrepriseSlotMode,
  saveServiceDetail,
  loadDemandes,
  addDemande,
  isDemandeSeen,
  setDemandeSeen,
  markAllDemandesSeen,
  countUnseenDemandes,
  syncUserDemandesFromProfile,
  removeDemandesForUserEmail,
  PROFIL_LABELS,
  TYPE_LIEU_OPTIONS,
  INTENSITE_OPTIONS,
  SWISS_CANTONS,
  verifyAdminCode,
  isAdminTokenValid,
  clearAdminToken,
  getAdminTokenExpiresAt,
  CRENEAU_SOIR_WEEKEND,
  loadSiteSettings,
  saveSiteSettings,
} from "./storage";
import { toISODate, startOfWeekMonday } from "./dates";
import { CreneauxSoirWeekend } from "./WeekCalendar.jsx";

/** @param {import("./storage").UserProfile | null} raw */
function normalizeUser(raw) {
  if (!raw) return null;
  const profilType =
    raw.profilType === "entreprise" || raw.profilType === "particulier" || raw.profilType === "etudiant"
      ? raw.profilType
      : "etudiant";
  let age = null;
  if (typeof raw.age === "number" && !Number.isNaN(raw.age)) age = raw.age;
  else if (raw.age != null && raw.age !== "") {
    const n = parseInt(String(raw.age), 10);
    if (!Number.isNaN(n)) age = n;
  }
  const canton =
    typeof raw.canton === "string" && SWISS_CANTONS.some((c) => c.value === raw.canton)
      ? raw.canton
      : "";
  const ecole = raw.ecole != null ? String(raw.ecole) : "";
  return { ...raw, profilType, age, canton, ecole };
}

/** @param {import("./storage").SiteSettings} s */
function appearanceClassNames(s) {
  return [
    s.theme === "light" ? "theme-light" : "",
    s.fontSize === "large" ? "font-large" : "",
    s.density === "compact" ? "density-compact" : "",
    s.highContrast ? "high-contrast" : "",
    s.reducedMotion ? "reduced-motion" : "",
    s.showHints ? "" : "hide-hints",
  ]
    .filter(Boolean)
    .join(" ");
}

/** @param {string} sectionId @param {boolean} reducedMotion */
function scrollToLandingSection(sectionId, reducedMotion) {
  const el = document.getElementById(sectionId);
  if (!el) return;
  el.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
}

/** Logo exact fourni (fichier `public/uniclean-logo.png`). */
function UniFreshLogo() {
  return (
    <span className="brand-logo" aria-hidden="true">
      <img
        className="brand-logo-img"
        src="/uniclean-logo.png"
        alt=""
        width={48}
        height={48}
        decoding="async"
        fetchPriority="high"
      />
    </span>
  );
}

const ADVISOR_QUICK_QUESTIONS = [
  "Comment m'inscrire ?",
  "Quelle difference entre etudiant et entreprise ?",
  "Comment envoyer une demande de nettoyage ?",
  "Comment changer mes informations ?",
];

/**
 * @param {string} rawQuestion
 * @returns {string}
 */
function getAdvisorAnswer(rawQuestion) {
  const q = String(rawQuestion || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  const hasAny = (...words) => words.some((w) => q.includes(w));

  if (
    hasAny("changer", "modifier", "corriger", "mise a jour", "mettre a jour") &&
    hasAny("nom", "entreprise", "societe", "raison sociale", "email", "telephone", "prenom")
  ) {
    return "Pour modifier vos informations (nom d'entreprise, e-mail, telephone...), deconnectez-vous puis refaites l'inscription avec les bonnes donnees sur cet appareil. Le site ne propose pas encore l'edition directe du profil apres inscription.";
  }
  if (hasAny("supprimer", "effacer", "retirer") && hasAny("compte", "inscription", "donnees")) {
    return "La suppression de compte n'est pas encore disponible en un clic. Pour repartir de zero sur cet appareil, vous pouvez effacer les donnees du navigateur (localStorage) puis vous reinscrire.";
  }
  if (hasAny("mot de passe", "password")) {
    return "Il n'y a pas de mot de passe classique ici: la validation se fait via code envoye par e-mail pendant l'inscription.";
  }

  if (q.includes("inscri") || q.includes("compte") || q.includes("code")) {
    return "Pour vous inscrire: choisissez votre profil, remplissez le formulaire, puis validez le code recu par e-mail. Ensuite vous pourrez vous connecter avec le meme e-mail sur cet appareil.";
  }
  if (q.includes("entreprise") || q.includes("particulier") || q.includes("etudiant") || q.includes("profil")) {
    return "Le site a 3 profils: etudiant (missions proposees par UniFresh), entreprise (demande de nettoyage pro), particulier (besoin a domicile). Selectionnez le profil qui correspond a votre besoin dans l'inscription.";
  }
  if (q.includes("demande") || q.includes("nettoyage") || q.includes("devis") || q.includes("formulaire")) {
    return "Apres connexion (entreprise ou particulier), ouvrez le formulaire de demande, indiquez l'adresse, la surface, l'intensite, le type de lieu et les creneaux. Puis cliquez sur 'Envoyer la demande'.";
  }
  if (q.includes("reglage") || q.includes("theme") || q.includes("apparence") || q.includes("texte")) {
    return "Le bouton 'Reglages' permet de modifier l'apparence du site (theme, taille du texte, densite, contraste, animations), meme sans compte.";
  }
  if (q.includes("contact") || q.includes("mail") || q.includes("email")) {
    return "Vous pouvez contacter UniFresh a l'adresse: unifreshbynk@gmail.com.";
  }
  return "Je peux vous aider sur: inscription, choix du profil, demande de nettoyage, modification d'informations et reglages d'apparence. Posez-moi une question plus precise sur le fonctionnement du site.";
}

function AiAdvisorWidget() {
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState(() => [
    {
      role: "assistant",
      text: "Bonjour, je suis le conseiller IA UniFresh. Je reponds aux questions sur le fonctionnement du site.",
    },
  ]);

  const ask = useCallback(
    (text) => {
      const q = String(text || "").trim();
      if (!q) return;
      setMessages((prev) => [...prev, { role: "user", text: q }, { role: "assistant", text: getAdvisorAnswer(q) }]);
      setQuestion("");
      if (!open) setOpen(true);
    },
    [open]
  );

  function submit(e) {
    e.preventDefault();
    ask(question);
  }

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <div className={`advisor-wrap ${open ? "open" : ""}`}>
      <button
        type="button"
        className="advisor-toggle advisor-toggle-round"
        aria-label={open ? "Fermer l'aide" : "Ouvrir l'aide"}
        onClick={() => setOpen((v) => !v)}
      >
        <span aria-hidden="true" className="advisor-avatar">
          👩‍💼
        </span>
      </button>
      {open ? (
        <>
          <button
            type="button"
            className="advisor-backdrop"
            aria-label="Fermer l'aide"
            onClick={() => setOpen(false)}
          />
          <section className="advisor-panel card" aria-label="Aide du site">
            <button
              type="button"
              className="advisor-close btn ghost"
              aria-label="Fermer l'aide"
              onClick={() => setOpen(false)}
            >
              ✕
            </button>
            <h3>Aide UniFresh</h3>
            <p className="hint">Questions sur le site, les profils, les demandes et l'inscription.</p>
            <div className="advisor-chat">
              {messages.map((m, idx) => (
                <p key={`${m.role}-${idx}`} className={`advisor-msg ${m.role === "user" ? "user" : "assistant"}`}>
                  {m.text}
                </p>
              ))}
            </div>
            <div className="advisor-quick">
              {ADVISOR_QUICK_QUESTIONS.map((q) => (
                <button key={q} type="button" className="btn ghost" onClick={() => ask(q)}>
                  {q}
                </button>
              ))}
            </div>
            <form className="advisor-form" onSubmit={submit}>
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Posez votre question sur le site..."
              />
              <button type="submit" className="btn primary">
                Envoyer
              </button>
            </form>
          </section>
        </>
      ) : null}
    </div>
  );
}

export default function App() {
  const [adminOpen, setAdminOpen] = useState(false);
  const [demandesVersion, setDemandesVersion] = useState(0);
  const [user, setUser] = useState(() => {
    const stored = normalizeUser(loadUser());
    if (!stored) return null;
    const sessionEmail = (loadSessionEmail() || "").trim().toLowerCase();
    if (!sessionEmail) {
      // Compatibility: old installs had no session key and stayed connected.
      saveSessionEmail(String(stored.email || "").trim().toLowerCase());
      return stored;
    }
    return String(stored.email || "").trim().toLowerCase() === sessionEmail ? stored : null;
  });
  const [serviceWeeks, setServiceWeeks] = useState({});
  const [serviceRecurringTags, setServiceRecurringTags] = useState([]);
  const [entrepriseSlotMode, setEntrepriseSlotMode] = useState("week");
  const [weekAnchor, setWeekAnchor] = useState(() => startOfWeekMonday(new Date()));
  const [appearance, setAppearance] = useState(loadSiteSettings);
  const [logoutConfirmOpen, setLogoutConfirmOpen] = useState(false);
  const [serviceRequestSubmitted, setServiceRequestSubmitted] = useState(false);
  const shellAppearance = useMemo(() => appearanceClassNames(appearance), [appearance]);

  const updateAppearance = useCallback((key, value) => {
    setAppearance((prev) => {
      const next = { ...prev, [key]: value };
      saveSiteSettings(next);
      return next;
    });
  }, []);

  const mondayISO = useMemo(() => toISODate(weekAnchor), [weekAnchor]);

  const toggleServiceTag = useCallback(
    (tagId) => {
      const weekKey = mondayISO;
      setServiceWeeks((prev) => {
        const next = { ...prev };
        const current = new Set(next[weekKey] || []);
        if (current.has(tagId)) current.delete(tagId);
        else current.add(tagId);
        const arr = Array.from(current).sort();
        if (arr.length === 0) delete next[weekKey];
        else next[weekKey] = arr;
        saveServiceWeeks(next);
        return next;
      });
    },
    [mondayISO]
  );

  const toggleServiceRecurringTag = useCallback((tagId) => {
    setServiceRecurringTags((prev) => {
      const s = new Set(prev);
      if (s.has(tagId)) s.delete(tagId);
      else s.add(tagId);
      const arr = Array.from(s).sort();
      saveServiceRecurringTags(arr);
      return arr;
    });
  }, []);

  const isServiceTagOn = (tagId) => {
    const tags = serviceWeeks[mondayISO];
    return (tags || []).includes(tagId);
  };

  const isRecurringTagOn = (tagId) => serviceRecurringTags.includes(tagId);

  if (!user) {
    if (adminOpen) {
      return (
        <AdminPanel
          onClose={() => setAdminOpen(false)}
          demandesVersion={demandesVersion}
          onDemandesChange={() => setDemandesVersion((v) => v + 1)}
          appearance={appearance}
          onUpdateAppearance={updateAppearance}
          shellAppearance={shellAppearance}
        />
      );
    }
    return (
      <RegistrationForm
        onRegistered={(profile) => {
          saveUser(profile);
          saveSessionEmail(String(profile.email || "").trim().toLowerCase());
          addDemande({
            kind: "inscription",
            profilType: profile.profilType,
            nom: profile.nom,
            prenom: profile.prenom,
            email: profile.email,
            telephone: profile.telephone,
            payload: {
              age: profile.age,
              canton: profile.canton,
              ecole: profile.ecole,
            },
          });
          setDemandesVersion((v) => v + 1);
          setUser(normalizeUser(profile));
        }}
        onLogin={(profile) => {
          saveSessionEmail(String(profile.email || "").trim().toLowerCase());
          setUser(normalizeUser(profile));
        }}
        onOpenAdmin={() => setAdminOpen(true)}
        adminUnseenCount={countUnseenDemandes()}
        appearance={appearance}
        onUpdateAppearance={updateAppearance}
        shellAppearance={shellAppearance}
      />
    );
  }

  const isEtudiant = user.profilType === "etudiant";
  const tagline =
    user.profilType === "entreprise"
      ? "Nettoyage pour les pros"
      : user.profilType === "particulier"
        ? "Nettoyage à domicile"
        : "Nettoyage étudiant, à côté des cours";

  return (
    <div className={["shell", shellAppearance].filter(Boolean).join(" ")}>
      <header className="top">
        <div className="brand">
          <UniFreshLogo />
          <div>
            <h1>UniFresh</h1>
            <p>{tagline}</p>
          </div>
        </div>
        <div className="user-strip">
          <GlobalSettingsMenu
            appearance={appearance}
            onUpdateAppearance={updateAppearance}
            account={user}
            onSaveAccount={(profile) => {
              const normalized = normalizeUser(profile);
              saveUser(normalized);
              syncUserDemandesFromProfile(normalized);
              setDemandesVersion((v) => v + 1);
              setUser(normalized);
            }}
            onDeleteAccount={() => {
              removeDemandesForUserEmail(user.email);
              clearUser();
              clearSessionEmail();
              setDemandesVersion((v) => v + 1);
              setServiceRequestSubmitted(false);
              setUser(null);
            }}
          />
          <span className="user-name">
            {[user.prenom, user.nom].filter(Boolean).join(" ") || user.nom}
          </span>
          <span className="user-badge">{PROFIL_LABELS[user.profilType]}</span>
          {user.age != null ? <span className="user-meta">{user.age} ans</span> : null}
          {isEtudiant && user.canton ? (
            <span className="user-meta">
              {SWISS_CANTONS.find((c) => c.value === user.canton)?.label ?? user.canton}
            </span>
          ) : null}
          {isEtudiant && user.ecole ? <span className="user-meta">{user.ecole}</span> : null}
          <span className="user-meta">{user.email}</span>
          {!logoutConfirmOpen ? (
            <button type="button" className="btn ghost" onClick={() => setLogoutConfirmOpen(true)}>
              Déconnexion
            </button>
          ) : (
            <div className="settings-danger-box user-logout-confirm" role="alert">
              <p>Êtes-vous sûr de vouloir vous déconnecter ?</p>
              <div className="settings-danger-actions">
                <button type="button" className="btn ghost" onClick={() => setLogoutConfirmOpen(false)}>
                  Annuler
                </button>
                <button
                  type="button"
                  className="btn primary"
                  onClick={() => {
                    clearSessionEmail();
                    setServiceRequestSubmitted(false);
                    setUser(null);
                    setLogoutConfirmOpen(false);
                  }}
                >
                  Oui, me déconnecter
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="main">
        {isEtudiant ? (
          <section className="intro card etudiant-accueil">
            <h2>Merci pour votre inscription</h2>
            <p className="etudiant-accueil-thanks">
              {user.prenom ? (
                <>
                  Bonjour <strong>{user.prenom}</strong>, votre inscription a bien été enregistrée.
                </>
              ) : (
                <>Votre inscription a bien été enregistrée.</>
              )}{" "}
              Nous sommes ravis de vous compter parmi les étudiant·es partenaires d’UniFresh.
              {user.ecole ? (
                <>
                  {" "}
                  Nous avons bien noté votre établissement : <strong>{user.ecole}</strong>
                  {user.canton
                    ? ` (${SWISS_CANTONS.find((c) => c.value === user.canton)?.label ?? user.canton}).`
                    : "."}
                </>
              ) : null}
            </p>
            <p>
              Vous n’avez rien d’autre à remplir ici pour l’instant : <strong>nous vous contacterons</strong>{" "}
              par téléphone ou par e-mail pour vous proposer des missions de nettoyage et convenir
              avec vous des horaires qui s’adaptent à vos cours.
            </p>
            <p className="etudiant-accueil-suite">
              Conservez bien ce compte : vos coordonnées nous permettent de vous joindre. En cas de
              changement (numéro, e-mail…), déconnectez-vous puis inscrivez-vous à nouveau avec les
              bonnes informations.
            </p>
          </section>
        ) : (
          <>
            {!serviceRequestSubmitted ? (
              <section className="intro card">
                <h2>Demande de nettoyage</h2>
                <p>
                  Renseignez le formulaire ci-dessous : surface, type de locaux et niveau de
                  salissure. Ensuite, précisez les créneaux pour une visite ou une intervention
                  {user.profilType === "entreprise"
                    ? " (une semaine précise ou un besoin régulier qui se répète)."
                    : "."}{" "}
                  UniFresh vous recontactera rapidement.
                </p>
              </section>
            ) : null}
            <ClientServiceForm
              profilType={user.profilType}
              entrepriseSlotMode={entrepriseSlotMode}
              setEntrepriseSlotMode={(mode) => {
                setEntrepriseSlotMode(mode);
                saveEntrepriseSlotMode(mode);
              }}
              weekAnchor={weekAnchor}
              setWeekAnchor={setWeekAnchor}
              onToggleWeekTag={toggleServiceTag}
              isWeekTagOn={isServiceTagOn}
              onToggleRecurringTag={toggleServiceRecurringTag}
              isRecurringTagOn={isRecurringTagOn}
              onSubmitted={(data) => {
                addDemande({
                  kind: "demande_service",
                  profilType: user.profilType,
                  nom: user.nom,
                  prenom: user.prenom,
                  email: user.email,
                  telephone: user.telephone,
                  payload: data,
                });
                setDemandesVersion((v) => v + 1);
                setServiceRequestSubmitted(true);
              }}
            />
          </>
        )}
      </main>

      <footer className="foot">
        <p>UniFresh · étudiants, entreprises & particuliers</p>
        <p>
          Site sécurisé · Contact: <a href="mailto:unifreshbynk@gmail.com">unifreshbynk@gmail.com</a>
        </p>
      </footer>
      <AiAdvisorWidget />
    </div>
  );
}

function ClientServiceForm({
  profilType,
  entrepriseSlotMode,
  setEntrepriseSlotMode,
  weekAnchor,
  setWeekAnchor,
  onToggleWeekTag,
  isWeekTagOn,
  onToggleRecurringTag,
  isRecurringTagOn,
  onSubmitted,
}) {
  const [surfaceM2, setSurfaceM2] = useState("");
  const [intensite, setIntensite] = useState("");
  const [typeLieu, setTypeLieu] = useState("");
  const [typeLieuAutre, setTypeLieuAutre] = useState("");
  const [detailsLavage, setDetailsLavage] = useState("");
  const [notesComplementaires, setNotesComplementaires] = useState("");
  const [adresse, setAdresse] = useState("");
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function persistPartial() {
    saveServiceDetail({
      surfaceM2,
      intensite,
      typeLieu,
      typeLieuAutre,
      detailsLavage,
      notesComplementaires,
      adresse,
    });
  }

  function submit(e) {
    e.preventDefault();
    const m2 = parseFloat(String(surfaceM2).replace(",", "."));
    if (Number.isNaN(m2) || m2 < 1 || m2 > 500000) {
      setError("Indiquez une surface valide en m² (entre 1 et 500 000).");
      return;
    }
    if (adresse.trim().length < 12) {
      setError(
        "Indiquez l’adresse complète des locaux (rue, numéro, code postal et ville — au moins une ligne claire)."
      );
      return;
    }
    if (!intensite) {
      setError("Choisissez le niveau de nettoyage : léger, moyen ou gros travail.");
      return;
    }
    if (!typeLieu) {
      setError("Indiquez le type de locaux à nettoyer.");
      return;
    }
    if (typeLieu === "autre" && !typeLieuAutre.trim()) {
      setError("Précisez le type de lieu dans le champ « Autre ».");
      return;
    }
    if (detailsLavage.trim().length < 10) {
      setError("Décrivez ce que nous devons laver (au moins quelques mots).");
      return;
    }
    setError("");
    const payload = {
      surfaceM2: String(m2),
      intensite,
      typeLieu,
      typeLieuAutre: typeLieu === "autre" ? typeLieuAutre.trim() : "",
      detailsLavage: detailsLavage.trim(),
      notesComplementaires: notesComplementaires.trim(),
      adresse: adresse.trim(),
    };
    saveServiceDetail(payload);
    const selectedWeekTags = ["soir_semaine", "samedi", "dimanche"].filter((id) => isWeekTagOn(id));
    const selectedRecurringTags =
      profilType === "entreprise" && entrepriseSlotMode === "recurring"
        ? ["soir_semaine", "samedi", "dimanche"].filter((id) => isRecurringTagOn(id))
        : [];
    onSubmitted({
      ...payload,
      entrepriseSlotMode,
      selectedWeekTags,
      selectedRecurringTags,
    });
    setSurfaceM2(payload.surfaceM2);
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <section className="card client-service-page">
        <h2 className="client-service-title">Merci pour votre demande</h2>
        <p className="client-service-lead">
          Merci pour votre inscription et votre confiance. Nous avons bien reçu votre formulaire et
          nous vous contacterons bientôt.
        </p>
      </section>
    );
  }

  return (
    <section className="card client-service-page">
      <h2 className="client-service-title">Formulaire de demande</h2>
      <p className="client-service-lead">
        Ces informations nous permettent d’estimer la charge de travail et de vous proposer un
        devis adapté.
      </p>

      <form className="form client-service-form" onSubmit={submit} noValidate>
        {error ? (
          <div className="alert" role="alert">
            {error}
          </div>
        ) : null}
        <div className="form-section">
          <h3 className="form-section-title">Adresse d’intervention</h3>
          <label className="service-textarea-label">
            <span>Adresse complète des locaux à nettoyer</span>
            <textarea
              className="service-textarea"
              rows={3}
              value={adresse}
              onChange={(e) => {
                setAdresse(e.target.value);
              }}
              onBlur={persistPartial}
              placeholder="Rue et numéro, code postal, ville (et complément d’accès si utile : étage, digicode…)"
            />
          </label>
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Surface à nettoyer</h3>
          <label>
            <span>Superficie totale (m²)</span>
            <input
              type="text"
              inputMode="decimal"
              autoComplete="off"
              value={surfaceM2}
              onChange={(e) => {
                setSurfaceM2(e.target.value);
              }}
              onBlur={persistPartial}
              placeholder="Ex. : 250 ou 120,5"
            />
          </label>
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Niveau de nettoyage</h3>
          <div className="intensite-grid">
            {INTENSITE_OPTIONS.map((opt) => (
              <label
                key={opt.id}
                className={`intensite-option ${intensite === opt.id ? "selected" : ""}`}
              >
                <input
                  type="radio"
                  name="intensite"
                  value={opt.id}
                  checked={intensite === opt.id}
                  onChange={() => {
                    setIntensite(opt.id);
                  }}
                />
                <span className="intensite-option-title">{opt.label}</span>
                <span className="intensite-option-desc">{opt.desc}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Type de locaux</h3>
          <div className="type-lieu-list">
            {TYPE_LIEU_OPTIONS.map((opt) => (
              <label key={opt.id} className={`type-lieu-row ${typeLieu === opt.id ? "selected" : ""}`}>
                <input
                  type="radio"
                  name="typeLieu"
                  value={opt.id}
                  checked={typeLieu === opt.id}
                  onChange={() => {
                    setTypeLieu(opt.id);
                  }}
                />
                <span className="type-lieu-body">
                  <span className="type-lieu-label">{opt.label}</span>
                  <span className="type-lieu-desc">{opt.desc}</span>
                </span>
              </label>
            ))}
          </div>
          {typeLieu === "autre" ? (
            <label className="type-lieu-autre">
              <span>Précisez le type de lieu</span>
              <input
                type="text"
                value={typeLieuAutre}
                onChange={(e) => {
                  setTypeLieuAutre(e.target.value);
                }}
                onBlur={persistPartial}
                placeholder="Ex. : restaurant, salle de sport…"
              />
            </label>
          ) : null}
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Ce que nous devons laver</h3>
          <label className="service-textarea-label">
            <span>Détail des zones et tâches</span>
            <textarea
              className="service-textarea"
              rows={6}
              value={detailsLavage}
              onChange={(e) => {
                setDetailsLavage(e.target.value);
              }}
              onBlur={persistPartial}
              placeholder="Ex. : sols des open spaces et couloirs, vitres intérieures des bureaux, 4 sanitaires avec cabines, cuisine collective (plans de travail, frigo extérieur), poubelles des open spaces…"
            />
          </label>
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Informations complémentaires (optionnel)</h3>
          <label className="service-textarea-label">
            <span>Fréquence souhaitée, contraintes d’accès, matériel sur place…</span>
            <textarea
              className="service-textarea"
              rows={3}
              value={notesComplementaires}
              onChange={(e) => {
                setNotesComplementaires(e.target.value);
              }}
              onBlur={persistPartial}
              placeholder="Ex. : intervention possible uniquement après 19 h ; badge obligatoire à l’accueil…"
            />
          </label>
        </div>

        <div className="form-section">
          <h3 className="form-section-title">Créneaux souhaités</h3>
          <p className="hint">
            Choisissez les moments où une visite/intervention est possible. Vous pouvez cocher 1, 2
            ou 3 créneaux.
          </p>
          {profilType === "entreprise" ? (
            <>
              <div className="slot-mode-tabs" role="tablist" aria-label="Type de planification">
                <button
                  type="button"
                  role="tab"
                  aria-selected={entrepriseSlotMode === "week"}
                  className={`slot-mode-tab ${entrepriseSlotMode === "week" ? "active" : ""}`}
                  onClick={() => setEntrepriseSlotMode("week")}
                >
                  Pour une semaine précise
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={entrepriseSlotMode === "recurring"}
                  className={`slot-mode-tab ${entrepriseSlotMode === "recurring" ? "active" : ""}`}
                  onClick={() => setEntrepriseSlotMode("recurring")}
                >
                  Chaque semaine (régulier)
                </button>
              </div>
              {entrepriseSlotMode === "week" ? (
                <CreneauxSoirWeekend
                  showWeekNav
                  weekAnchor={weekAnchor}
                  setWeekAnchor={setWeekAnchor}
                  onToggleTag={onToggleWeekTag}
                  isTagOn={isWeekTagOn}
                  lead="Choisissez les créneaux pour cette semaine."
                  hint="Cochez vos créneaux directement dans ce formulaire."
                />
              ) : (
                <CreneauxSoirWeekend
                  showWeekNav={false}
                  onToggleTag={onToggleRecurringTag}
                  isTagOn={isRecurringTagOn}
                  recurringTitle="Besoin régulier"
                  recurringSubtitle="Ces mêmes créneaux seront répétés toutes les semaines."
                  lead="Choisissez les créneaux fixes à répéter chaque semaine."
                  hint="Ces créneaux sont inclus dans votre demande."
                />
              )}
            </>
          ) : (
            <CreneauxSoirWeekend
              showWeekNav
              weekAnchor={weekAnchor}
              setWeekAnchor={setWeekAnchor}
              onToggleTag={onToggleWeekTag}
              isTagOn={isWeekTagOn}
              lead="Choisissez les créneaux qui vous conviennent."
              hint="Ces créneaux sont inclus dans votre demande."
            />
          )}
        </div>

        <button type="submit" className="btn primary">
          Envoyer la demande
        </button>
      </form>
    </section>
  );
}

function AdminPanel({ onClose, demandesVersion, onDemandesChange, appearance, onUpdateAppearance, shellAppearance }) {
  const [accessCode, setAccessCode] = useState("");
  const [isAllowed, setIsAllowed] = useState(() => isAdminTokenValid());
  const [authError, setAuthError] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [activeProfileTab, setActiveProfileTab] = useState("etudiant");
  const [inscriptionsOpen, setInscriptionsOpen] = useState(false);
  const demandes = useMemo(() => {
    const stored = loadDemandes();
    if (stored.length > 0) return stored.slice().reverse();

    // Fallback for older data entered before admin logging existed.
    const fallback = [];
    const currentUser = loadUser();
    if (currentUser) {
      fallback.push({
        id: `fallback_user_${String(currentUser.email || "unknown")}`,
        createdAt: new Date().toISOString(),
        kind: "inscription",
        profilType: currentUser.profilType || "etudiant",
        nom: currentUser.nom || "",
        prenom: currentUser.prenom || "",
        email: currentUser.email || "",
        telephone: currentUser.telephone || "",
        payload: {
          age: currentUser.age ?? null,
          canton: currentUser.canton || "",
          ecole: currentUser.ecole || "",
          source: "Données existantes (avant journal admin)",
        },
      });

      const detail = loadServiceDetail();
      const hasService =
        (detail.adresse || "").trim() ||
        (detail.surfaceM2 || "").trim() ||
        (detail.detailsLavage || "").trim() ||
        (detail.notesComplementaires || "").trim();
      if (hasService && (currentUser.profilType === "entreprise" || currentUser.profilType === "particulier")) {
        const weeks = loadServiceWeeks();
        const recurring = loadServiceRecurringTags();
        fallback.push({
          id: `fallback_service_${String(currentUser.email || "unknown")}`,
          createdAt: new Date().toISOString(),
          kind: "demande_service",
          profilType: currentUser.profilType,
          nom: currentUser.nom || "",
          prenom: currentUser.prenom || "",
          email: currentUser.email || "",
          telephone: currentUser.telephone || "",
          payload: {
            ...detail,
            entrepriseSlotMode: loadEntrepriseSlotMode(),
            selectedWeekTags: Object.values(weeks).flat(),
            selectedRecurringTags: recurring,
            source: "Données existantes (avant journal admin)",
          },
        });
      }
    }
    return fallback.reverse();
  }, [demandesVersion]);
  const currentProfileDemandes = useMemo(
    () => demandes.filter((d) => d.profilType === activeProfileTab),
    [demandes, activeProfileTab]
  );
  const allInscriptions = useMemo(() => demandes.filter((d) => d.kind === "inscription"), [demandes]);
  const currentServiceDemandes = useMemo(
    () => currentProfileDemandes.filter((d) => d.kind === "demande_service"),
    [currentProfileDemandes]
  );
  const groupByDay = useCallback((items) => {
    /** @type {Record<string, typeof items>} */
    const byDay = {};
    for (const item of items) {
      const dayKey = String(item.createdAt || "").slice(0, 10) || "inconnu";
      if (!byDay[dayKey]) byDay[dayKey] = [];
      byDay[dayKey].push(item);
    }
    return Object.entries(byDay)
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([dayKey, dayItems]) => ({ dayKey, items: dayItems }));
  }, []);
  const allInscriptionsByDay = useMemo(() => groupByDay(allInscriptions), [allInscriptions, groupByDay]);
  const currentServiceByDay = useMemo(() => groupByDay(currentServiceDemandes), [currentServiceDemandes, groupByDay]);
  const serviceCountByProfile = useMemo(
    () => ({
      etudiant: demandes.filter((d) => d.profilType === "etudiant" && d.kind === "demande_service").length,
      entreprise: demandes.filter((d) => d.profilType === "entreprise" && d.kind === "demande_service").length,
      particulier: demandes.filter((d) => d.profilType === "particulier" && d.kind === "demande_service").length,
    }),
    [demandes]
  );
  const unseenServicesByProfile = useMemo(
    () => ({
      etudiant: demandes.filter(
        (d) => d.profilType === "etudiant" && d.kind === "demande_service" && !isDemandeSeen(d)
      ).length,
      entreprise: demandes.filter(
        (d) => d.profilType === "entreprise" && d.kind === "demande_service" && !isDemandeSeen(d)
      ).length,
      particulier: demandes.filter(
        (d) => d.profilType === "particulier" && d.kind === "demande_service" && !isDemandeSeen(d)
      ).length,
    }),
    [demandes]
  );
  const totalServiceDemandes = useMemo(
    () => demandes.filter((d) => d.kind === "demande_service").length,
    [demandes]
  );
  const totalUnseenServices = useMemo(
    () => demandes.filter((d) => d.kind === "demande_service" && !isDemandeSeen(d)).length,
    [demandes]
  );
  const unseenInscriptions = useMemo(
    () => allInscriptions.filter((d) => !isDemandeSeen(d)).length,
    [allInscriptions]
  );
  const canPersistSeen = useCallback((d) => !String(d.id || "").startsWith("fallback_"), []);

  function toggleDemandeSeen(demandeId, seen) {
    if (setDemandeSeen(demandeId, seen)) onDemandesChange?.();
  }

  function markAllSeen() {
    if (markAllDemandesSeen() > 0) onDemandesChange?.();
  }

  function profileTabLabel(profileKey, label) {
    const total = serviceCountByProfile[profileKey];
    const unseen = unseenServicesByProfile[profileKey];
    if (unseen > 0) return `${label} (${total} · ${unseen} non lue${unseen > 1 ? "s" : ""})`;
    return `${label} (${total})`;
  }

  useEffect(() => {
    if (!inscriptionsOpen) return;
    function onKey(e) {
      if (e.key === "Escape") setInscriptionsOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [inscriptionsOpen]);

  useEffect(() => {
    if (!isAllowed) return;
    const interval = setInterval(() => {
      if (!isAdminTokenValid()) {
        setIsAllowed(false);
        setAuthError("Session admin expirée. Reconnectez-vous.");
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [isAllowed]);

  function renderDemandesByDay(groups, keyPrefix) {
    if (groups.length === 0) return <p className="hint">Aucune entrée.</p>;
    return (
      <div className="admin-demandes-list">
        {groups.map((group) => (
          <section key={`${keyPrefix}-${group.dayKey}`} className="admin-day-group">
            <h4 className="admin-day-title">
              {new Date(`${group.dayKey}T00:00:00`).toLocaleDateString("fr-FR", {
                weekday: "long",
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </h4>
            {group.items.map((d) => (
              <AdminDemandeCard
                key={d.id}
                d={d}
                slotLabelById={slotLabelById}
                canToggleSeen={canPersistSeen(d)}
                onToggleSeen={toggleDemandeSeen}
              />
            ))}
          </section>
        ))}
      </div>
    );
  }
  const slotLabelById = useMemo(
    () => Object.fromEntries(CRENEAU_SOIR_WEEKEND.map((s) => [s.id, s.label])),
    []
  );
  async function unlock(e) {
    e.preventDefault();
    if (!accessCode.trim()) {
      setAuthError("Code requis.");
      return;
    }
    setIsVerifying(true);
    setAuthError("Vérification...");
    const success = await verifyAdminCode(accessCode.trim());
    setIsVerifying(false);
    if (success) {
      setIsAllowed(true);
      setAccessCode("");
      setAuthError("");
      console.log("[ADMIN] Connexion réussie");
    } else {
      setAuthError("Code admin invalide.");
      setAccessCode("");
    }
  }

  function logoutAdmin() {
    clearAdminToken();
    setIsAllowed(false);
    setAccessCode("");
    setAuthError("");
    console.log("[ADMIN] Déconnexion admin");
  }

  const adminShellClass = ["shell", "landing", shellAppearance].filter(Boolean).join(" ");

  if (!isAllowed) {
    return (
      <div className={adminShellClass}>
        <div className="landing-settings-row">
          <GlobalSettingsMenu appearance={appearance} onUpdateAppearance={onUpdateAppearance} />
        </div>
        <section className="card form-card">
          <h2>Accès admin</h2>
          <form className="form" onSubmit={unlock} noValidate>
            {authError ? (
              <div className="alert" role="alert">
                {authError}
              </div>
            ) : null}
            <label>
              <span>Code d'accès</span>
              <input
                type="password"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                placeholder="Code admin"
              />
            </label>
            <button type="submit" className="btn primary" disabled={isVerifying}>
              {isVerifying ? "Vérification..." : "Ouvrir les demandes"}
            </button>
            <button type="button" className="btn ghost" onClick={onClose}>
              Retour
            </button>
          </form>
        </section>
      </div>
    );
  }

  return (
    <div className={adminShellClass}>
      <div className="landing-settings-row">
        <GlobalSettingsMenu appearance={appearance} onUpdateAppearance={onUpdateAppearance} />
      </div>
      <section className="card form-card admin-service-card">
        <div className="admin-session-bar">
          <p className="hint admin-session-expiry">
            Session active — expire à{" "}
            <strong>
              {getAdminTokenExpiresAt()
                ? new Date(getAdminTokenExpiresAt()).toLocaleTimeString("fr-FR", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  })
                : "—"}
            </strong>
          </p>
          <button type="button" className="btn ghost admin-logout-btn" onClick={logoutAdmin}>
            Déconnexion admin
          </button>
        </div>
        <div className="admin-panel-head">
          <div className="admin-panel-head-main">
            <h2>Demandes de service</h2>
            <p className="hint">
              {totalServiceDemandes === 0 ? (
                "Aucune demande de service pour le moment."
              ) : (
                <>
                  Total services: <strong>{totalServiceDemandes}</strong>
                  {totalUnseenServices > 0 ? (
                    <>
                      {" "}
                      · Non lues: <strong>{totalUnseenServices}</strong>
                    </>
                  ) : (
                    <> · Toutes lues</>
                  )}
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            className="admin-inscriptions-chip"
            onClick={() => setInscriptionsOpen(true)}
            aria-haspopup="dialog"
            aria-expanded={inscriptionsOpen}
            title="Voir toutes les inscriptions"
          >
            Inscr. {allInscriptions.length}
            {unseenInscriptions > 0 ? <span className="admin-inscriptions-chip-dot" aria-hidden /> : null}
          </button>
        </div>
        {totalUnseenServices > 0 ? (
          <button type="button" className="btn primary admin-mark-all-seen" onClick={markAllSeen}>
            Tout marquer comme vu
          </button>
        ) : null}
        <button type="button" className="btn ghost" onClick={onClose}>
          Fermer l'espace admin
        </button>
        {inscriptionsOpen ? (
          <div
            className="admin-inscriptions-backdrop"
            role="presentation"
            onClick={() => setInscriptionsOpen(false)}
          >
            <div
              className="admin-inscriptions-panel"
              role="dialog"
              aria-modal="true"
              aria-labelledby="admin-inscriptions-title"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="admin-inscriptions-panel-head">
                <h3 id="admin-inscriptions-title">Inscriptions ({allInscriptions.length})</h3>
                <button
                  type="button"
                  className="admin-inscriptions-close"
                  onClick={() => setInscriptionsOpen(false)}
                  aria-label="Fermer les inscriptions"
                >
                  ✕
                </button>
              </div>
              {renderDemandesByDay(allInscriptionsByDay, "insc-all")}
            </div>
          </div>
        ) : null}
        {totalServiceDemandes === 0 && allInscriptions.length > 0 ? (
          <p className="hint">Les inscriptions sont dans le bouton en haut à droite.</p>
        ) : null}
        {totalServiceDemandes === 0 && allInscriptions.length === 0 ? (
          <p>Aucune demande pour le moment.</p>
        ) : null}
        {totalServiceDemandes > 0 ? (
          <>
            <div className="slot-mode-tabs" role="tablist" aria-label="Profil de demandes de service">
              <button
                type="button"
                role="tab"
                aria-selected={activeProfileTab === "etudiant"}
                className={`slot-mode-tab ${activeProfileTab === "etudiant" ? "active" : ""}`}
                onClick={() => setActiveProfileTab("etudiant")}
              >
                {profileTabLabel("etudiant", "Étudiants")}
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={activeProfileTab === "entreprise"}
                className={`slot-mode-tab ${activeProfileTab === "entreprise" ? "active" : ""}`}
                onClick={() => setActiveProfileTab("entreprise")}
              >
                {profileTabLabel("entreprise", "Entreprises")}
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={activeProfileTab === "particulier"}
                className={`slot-mode-tab ${activeProfileTab === "particulier" ? "active" : ""}`}
                onClick={() => setActiveProfileTab("particulier")}
              >
                {profileTabLabel("particulier", "Particuliers")}
              </button>
            </div>
            {currentServiceDemandes.length === 0 ? (
              <p className="hint">Aucune demande de service pour ce profil.</p>
            ) : (
              <section className="admin-group admin-group-primary">
                {renderDemandesByDay(currentServiceByDay, "svc")}
              </section>
            )}
          </>
        ) : null}
      </section>
    </div>
  );
}

function AdminDemandeCard({ d, slotLabelById, canToggleSeen = false, onToggleSeen }) {
  const seen = isDemandeSeen(d);

  return (
    <article className={`admin-demande-card ${seen ? "seen" : "unseen"}`}>
      <div className="admin-demande-top">
        <span className={`admin-kind ${d.kind === "inscription" ? "inscription" : "service"}`}>
          {d.kind === "inscription" ? "Inscription" : "Demande service"}
        </span>
        <span className={`admin-seen-status ${seen ? "seen" : "unseen"}`}>
          {seen ? "Vu" : "Pas encore vu"}
        </span>
        <span className="admin-date">
          {new Date(d.createdAt).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })}
        </span>
      </div>
      <p className="admin-line">
        <strong>Profil:</strong> {PROFIL_LABELS[d.profilType]}
      </p>
      <p className="admin-line">
        <strong>Client:</strong> {[d.prenom, d.nom].filter(Boolean).join(" ") || d.nom}
      </p>
      <p className="admin-line">
        <strong>Contact:</strong> {d.email} · {d.telephone}
      </p>
      <div className="admin-details">
        {d.kind === "inscription" ? (
          <>
            {d.payload.age ? <p className="admin-line">Age: {String(d.payload.age)}</p> : null}
            {d.payload.canton ? <p className="admin-line">Canton: {String(d.payload.canton)}</p> : null}
            {d.payload.ecole ? <p className="admin-line">Ecole: {String(d.payload.ecole)}</p> : null}
          </>
        ) : (
          <>
            {d.payload.adresse ? (
              <p className="admin-line">
                <strong>Adresse:</strong> {String(d.payload.adresse)}
              </p>
            ) : null}
            <p className="admin-line">
              <strong>Surface:</strong> {String(d.payload.surfaceM2 || "-")} m2
            </p>
            <p className="admin-line">
              <strong>Intensité:</strong> {String(d.payload.intensite || "-")}
            </p>
            <p className="admin-line">
              <strong>Type de lieu:</strong> {String(d.payload.typeLieu || "-")}
            </p>
            {d.payload.detailsLavage ? (
              <p className="admin-line">
                <strong>Détails nettoyage:</strong> {String(d.payload.detailsLavage)}
              </p>
            ) : null}
            {d.payload.notesComplementaires ? (
              <p className="admin-line">
                <strong>Notes:</strong> {String(d.payload.notesComplementaires)}
              </p>
            ) : null}
            <div className="admin-slots">
              <strong>Créneaux:</strong>
              <ul>
                {[
                  ...(Array.isArray(d.payload.selectedWeekTags) ? d.payload.selectedWeekTags : []),
                  ...(Array.isArray(d.payload.selectedRecurringTags) ? d.payload.selectedRecurringTags : []),
                ]
                  .filter((v, i, arr) => arr.indexOf(v) === i)
                  .map((id) => (
                    <li key={`${d.id}-${String(id)}`}>{slotLabelById[String(id)] || String(id)}</li>
                  ))}
                {!(
                  (Array.isArray(d.payload.selectedWeekTags) && d.payload.selectedWeekTags.length > 0) ||
                  (Array.isArray(d.payload.selectedRecurringTags) && d.payload.selectedRecurringTags.length > 0)
                ) ? <li>Aucun créneau sélectionné</li> : null}
              </ul>
            </div>
          </>
        )}
        {d.payload.source ? <p className="hint">{String(d.payload.source)}</p> : null}
        {d.payload.profileUpdatedAt ? (
          <p className="hint">
            Informations compte mises à jour le{" "}
            {new Date(String(d.payload.profileUpdatedAt)).toLocaleString("fr-FR", {
              dateStyle: "short",
              timeStyle: "short",
            })}
          </p>
        ) : null}
      </div>
      {canToggleSeen && onToggleSeen ? (
        <div className="admin-seen-actions">
          {seen ? (
            <button type="button" className="btn ghost" onClick={() => onToggleSeen(d.id, false)}>
              Marquer comme non vu
            </button>
          ) : (
            <button type="button" className="btn primary" onClick={() => onToggleSeen(d.id, true)}>
              Marquer comme vu
            </button>
          )}
        </div>
      ) : null}
    </article>
  );
}

function GlobalSettingsMenu({ appearance, onUpdateAppearance, account, onSaveAccount, onDeleteAccount }) {
  const [open, setOpen] = useState(false);
  const [accountDraft, setAccountDraft] = useState(null);
  const [accountError, setAccountError] = useState("");
  const [accountInfo, setAccountInfo] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (!account) {
      setAccountDraft(null);
      setShowDeleteConfirm(false);
      return;
    }
    setAccountDraft({
      prenom: account.prenom || "",
      nom: account.nom || "",
      telephone: account.telephone || "",
      age: account.age != null ? String(account.age) : "",
      canton: account.canton || "",
      ecole: account.ecole || "",
    });
    setAccountError("");
    setAccountInfo("");
    setShowDeleteConfirm(false);
  }, [account, open]);

  function saveAccount(e) {
    e.preventDefault();
    if (!account || !accountDraft || !onSaveAccount) return;
    const nm = accountDraft.nom.trim();
    const tel = accountDraft.telephone.trim().replace(/\s/g, "");
    const pr = accountDraft.prenom.trim();
    if (!nm) {
      setAccountError("Indiquez un nom.");
      return;
    }
    if (account.profilType !== "entreprise" && !pr) {
      setAccountError("Indiquez un prénom.");
      return;
    }
    if (tel.length < 8) {
      setAccountError("Numéro de téléphone trop court.");
      return;
    }

    let ageOut = /** @type {number | null} */ (null);
    if (account.profilType === "etudiant") {
      const ageNum = parseInt(String(accountDraft.age).trim(), 10);
      if (!String(accountDraft.age).trim() || Number.isNaN(ageNum) || ageNum < 16 || ageNum > 110) {
        setAccountError("Âge invalide (entre 16 et 110 ans).");
        return;
      }
      ageOut = ageNum;
      if (!accountDraft.canton) {
        setAccountError("Choisissez le canton de votre établissement.");
        return;
      }
      const ec = accountDraft.ecole.trim();
      if (ec.length < 3) {
        setAccountError("Indiquez le nom de votre école ou établissement.");
        return;
      }
    }

    setAccountError("");
    onSaveAccount({
      ...account,
      prenom: account.profilType === "entreprise" ? "" : pr,
      nom: nm,
      telephone: tel,
      age: ageOut,
      canton: account.profilType === "etudiant" ? accountDraft.canton : "",
      ecole: account.profilType === "etudiant" ? accountDraft.ecole.trim() : "",
    });
    setAccountInfo("Modifications enregistrées.");
    setShowDeleteConfirm(false);
  }

  function confirmDeleteAccount() {
    if (!onDeleteAccount) return;
    onDeleteAccount();
    setOpen(false);
  }

  const panelClass = ["settings-panel", "card", account ? "settings-panel-wide" : ""].filter(Boolean).join(" ");

  return (
    <div className="settings-wrap">
      <button type="button" className="btn ghost" onClick={() => setOpen((v) => !v)}>
        Réglages
      </button>
      {open ? (
        <section className={panelClass}>
          <h3>Apparence</h3>
          <p className="hint">Ces réglages s’appliquent à tout le site, sans compte.</p>
          <label>
            <span>Thème</span>
            <select value={appearance.theme} onChange={(e) => onUpdateAppearance("theme", e.target.value)}>
              <option value="dark">Sombre</option>
              <option value="light">Clair</option>
            </select>
          </label>
          <label>
            <span>Taille du texte</span>
            <select value={appearance.fontSize} onChange={(e) => onUpdateAppearance("fontSize", e.target.value)}>
              <option value="normal">Normale</option>
              <option value="large">Grande</option>
            </select>
          </label>
          <label>
            <span>Densité</span>
            <select value={appearance.density} onChange={(e) => onUpdateAppearance("density", e.target.value)}>
              <option value="comfortable">Confortable</option>
              <option value="compact">Compacte</option>
            </select>
          </label>
          <label className="settings-check">
            <input
              type="checkbox"
              checked={appearance.showHints}
              onChange={(e) => onUpdateAppearance("showHints", e.target.checked)}
            />
            <span>Afficher les textes d’aide</span>
          </label>
          <label className="settings-check">
            <input
              type="checkbox"
              checked={appearance.highContrast}
              onChange={(e) => onUpdateAppearance("highContrast", e.target.checked)}
            />
            <span>Contraste renforcé</span>
          </label>
          <label className="settings-check">
            <input
              type="checkbox"
              checked={appearance.reducedMotion}
              onChange={(e) => onUpdateAppearance("reducedMotion", e.target.checked)}
            />
            <span>Réduire les animations</span>
          </label>

          {account && accountDraft ? (
            <form className="settings-section-divider form" onSubmit={saveAccount} noValidate>
              <h3>Compte</h3>
              <p className="hint">Modifiez vos informations. L’e-mail ne peut pas être changé ici.</p>
              {accountError ? (
                <div className="alert" role="alert">
                  {accountError}
                </div>
              ) : null}
              {accountInfo ? (
                <div className="success-banner" role="status">
                  {accountInfo}
                </div>
              ) : null}
              <label>
                <span>E-mail</span>
                <input type="email" value={account.email} readOnly disabled />
              </label>
              {account.profilType !== "entreprise" ? (
                <label>
                  <span>Prénom</span>
                  <input
                    type="text"
                    autoComplete="given-name"
                    value={accountDraft.prenom}
                    onChange={(e) => setAccountDraft((prev) => ({ ...prev, prenom: e.target.value }))}
                  />
                </label>
              ) : null}
              <label>
                <span>{account.profilType === "entreprise" ? "Raison sociale ou nom de l’entreprise" : "Nom"}</span>
                <input
                  type="text"
                  autoComplete={account.profilType === "entreprise" ? "organization" : "family-name"}
                  value={accountDraft.nom}
                  onChange={(e) => setAccountDraft((prev) => ({ ...prev, nom: e.target.value }))}
                />
              </label>
              <label>
                <span>Téléphone</span>
                <input
                  type="tel"
                  autoComplete="tel"
                  value={accountDraft.telephone}
                  onChange={(e) => setAccountDraft((prev) => ({ ...prev, telephone: e.target.value }))}
                />
              </label>
              {account.profilType === "etudiant" ? (
                <>
                  <label>
                    <span>Âge</span>
                    <input
                      type="number"
                      inputMode="numeric"
                      min={16}
                      max={110}
                      value={accountDraft.age}
                      onChange={(e) => setAccountDraft((prev) => ({ ...prev, age: e.target.value }))}
                    />
                  </label>
                  <label>
                    <span>Canton</span>
                    <select
                      value={accountDraft.canton}
                      onChange={(e) => setAccountDraft((prev) => ({ ...prev, canton: e.target.value }))}
                    >
                      <option value="">Choisissez votre canton</option>
                      {SWISS_CANTONS.map((c) => (
                        <option key={c.value} value={c.value}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    <span>École ou établissement</span>
                    <input
                      type="text"
                      autoComplete="organization"
                      value={accountDraft.ecole}
                      onChange={(e) => setAccountDraft((prev) => ({ ...prev, ecole: e.target.value }))}
                    />
                  </label>
                </>
              ) : null}
              <button type="submit" className="btn primary">
                Enregistrer les modifications
              </button>
              {!showDeleteConfirm ? (
                <button type="button" className="btn ghost settings-danger-btn" onClick={() => setShowDeleteConfirm(true)}>
                  Supprimer mon compte
                </button>
              ) : (
                <div className="settings-danger-box" role="alert">
                  <p>Êtes-vous sûr de vouloir supprimer le compte ?</p>
                  <div className="settings-danger-actions">
                    <button type="button" className="btn ghost" onClick={() => setShowDeleteConfirm(false)}>
                      Annuler
                    </button>
                    <button type="button" className="btn primary settings-danger-btn" onClick={confirmDeleteAccount}>
                      Oui, supprimer
                    </button>
                  </div>
                </div>
              )}
            </form>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}

function RegistrationForm({
  onRegistered,
  onLogin,
  onOpenAdmin,
  adminUnseenCount = 0,
  appearance,
  onUpdateAppearance,
  shellAppearance,
}) {
  const [email, setEmail] = useState("");
  const [prenom, setPrenom] = useState("");
  const [nom, setNom] = useState("");
  const [telephone, setTelephone] = useState("");
  const [age, setAge] = useState("");
  const [profilType, setProfilType] = useState(/** @type {"etudiant"|"entreprise"|"particulier"|""} */ (""));
  const [canton, setCanton] = useState("");
  const [ecole, setEcole] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pendingRegistration, setPendingRegistration] = useState(null);
  const [reviewRegistration, setReviewRegistration] = useState(null);
  const [confirmationCode, setConfirmationCode] = useState("");
  const [confirmError, setConfirmError] = useState("");
  const [confirmInfo, setConfirmInfo] = useState("");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginInfo, setLoginInfo] = useState("");
  const [loginCode, setLoginCode] = useState("");
  const [pendingLoginEmail, setPendingLoginEmail] = useState("");
  const [isLoginSubmitting, setIsLoginSubmitting] = useState(false);

  async function sendRegistrationCode(registrationPayload) {
    setError("");
    setConfirmError("");
    setConfirmInfo("");
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/register/send-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(registrationPayload),
      });
      if (!response.ok) {
        let serverMessage = "Impossible d'envoyer l'e-mail de confirmation.";
        try {
          const data = await response.json();
          if (data && typeof data.error === "string" && data.error.trim()) serverMessage = data.error;
        } catch {
          /* ignore */
        }
        setError(`${serverMessage} Vérifiez la configuration SMTP puis réessayez.`);
        return;
      }
      setPendingRegistration(registrationPayload);
      setConfirmationCode("");
      setConfirmInfo("Un code de confirmation a ete envoye a votre e-mail.");
      setReviewRegistration(null);
    } catch {
      setError("Serveur e-mail indisponible. Lancez `npm run server` puis réessayez.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function submitLogin(e) {
    e.preventDefault();
    const em = loginEmail.trim().toLowerCase();
    if (!em) {
      setLoginError("Indiquez l’e-mail utilisé lors de l’inscription.");
      return;
    }
    const existing = normalizeUser(loadUser());
    if (!existing || String(existing.email || "").trim().toLowerCase() !== em) {
      setLoginError("Aucun compte correspondant sur cet appareil. Merci de vous inscrire.");
      return;
    }
    setLoginError("");
    setLoginInfo("");
    setIsLoginSubmitting(true);
    try {
      const response = await fetch("/api/login/send-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: em }),
      });
      if (!response.ok) {
        let serverMessage = "Impossible d'envoyer le code de connexion.";
        try {
          const data = await response.json();
          if (data && typeof data.error === "string" && data.error.trim()) serverMessage = data.error;
        } catch {
          try {
            const raw = await response.text();
            if (raw && raw.trim()) serverMessage = raw.trim();
          } catch {
            /* ignore */
          }
        }
        setLoginError(`${serverMessage} Vérifiez la configuration SMTP puis réessayez.`);
        return;
      }
      setPendingLoginEmail(em);
      setLoginCode("");
      setLoginInfo("Un code de connexion a ete envoye a votre e-mail.");
    } catch {
      setLoginError("Serveur e-mail indisponible. Lancez `npm run server` puis réessayez.");
    } finally {
      setIsLoginSubmitting(false);
    }
  }

  async function submitLoginCode(e) {
    e.preventDefault();
    const em = pendingLoginEmail.trim().toLowerCase();
    if (!em) {
      setLoginError("Aucun e-mail en attente. Demandez un code de connexion.");
      return;
    }
    const code = loginCode.trim();
    if (!code) {
      setLoginError("Saisissez le code de connexion reçu par e-mail.");
      return;
    }

    const existing = normalizeUser(loadUser());
    if (!existing || String(existing.email || "").trim().toLowerCase() !== em) {
      setLoginError("Aucun compte correspondant sur cet appareil. Merci de vous inscrire.");
      setPendingLoginEmail("");
      return;
    }

    setLoginError("");
    setIsLoginSubmitting(true);
    try {
      const response = await fetch("/api/login/verify-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: em, code }),
      });
      if (!response.ok) {
        let serverMessage = "Code invalide ou expiré.";
        try {
          const data = await response.json();
          if (data && typeof data.error === "string" && data.error.trim()) serverMessage = data.error;
        } catch {
          /* ignore */
        }
        setLoginError(serverMessage);
        return;
      }
      onLogin(existing);
    } catch {
      setLoginError("Impossible de verifier le code pour le moment.");
    } finally {
      setIsLoginSubmitting(false);
    }
  }

  async function submit(e) {
    e.preventDefault();
    if (isSubmitting) return;
    const em = email.trim();
    const pr = prenom.trim();
    const nm = nom.trim();
    const tel = telephone.trim().replace(/\s/g, "");

    if (!profilType) {
      setError("Indiquez si vous êtes étudiant·e, une entreprise ou un particulier.");
      return;
    }
    if (!em || !nm || !tel) {
      setError("Merci de remplir tous les champs obligatoires.");
      return;
    }
    if (profilType !== "entreprise" && !pr) {
      setError("Merci d’indiquer votre prénom.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) {
      setError("Adresse e-mail invalide.");
      return;
    }
    if (tel.length < 8) {
      setError("Numéro de téléphone trop court.");
      return;
    }

    let ageOut = /** @type {number | null} */ (null);
    if (profilType === "etudiant") {
      const ageNum = parseInt(String(age).trim(), 10);
      if (!age.trim() || Number.isNaN(ageNum) || ageNum < 16 || ageNum > 110) {
        setError("Âge invalide (entre 16 et 110 ans).");
        return;
      }
      ageOut = ageNum;
      if (!canton) {
        setError("Choisissez le canton de votre établissement scolaire.");
        return;
      }
      const ec = ecole.trim();
      if (ec.length < 3) {
        setError("Indiquez le nom de votre école ou établissement (au moins 3 caractères).");
        return;
      }
    }

    const registrationPayload = {
      email: em,
      prenom: profilType === "entreprise" ? "" : pr,
      nom: nm,
      telephone: tel,
      age: ageOut,
      profilType,
      canton: profilType === "etudiant" ? canton : "",
      ecole: profilType === "etudiant" ? ecole.trim() : "",
    };

    setError("");
    setReviewRegistration(registrationPayload);
  }

  async function submitConfirmation(e) {
    e.preventDefault();
    if (!pendingRegistration) return;
    const code = confirmationCode.trim();
    if (!code) {
      setConfirmError("Saisissez le code recu par e-mail.");
      return;
    }
    setConfirmError("");
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/register/verify-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: pendingRegistration.email, code }),
      });
      if (!response.ok) {
        let serverMessage = "Code invalide ou expiré.";
        try {
          const data = await response.json();
          if (data && typeof data.error === "string" && data.error.trim()) serverMessage = data.error;
        } catch {
          /* ignore */
        }
        setConfirmError(serverMessage);
        return;
      }
      onRegistered(pendingRegistration);
    } catch {
      setConfirmError("Impossible de verifier le code pour le moment.");
    } finally {
      setIsSubmitting(false);
    }
  }

  const landingClass = ["shell", "landing", shellAppearance].filter(Boolean).join(" ");
  const reducedMotion = shellAppearance.includes("reduced-motion");

  return (
    <div className={landingClass}>
      <nav className="landing-scroll-nav" aria-label="Navigation inscription et connexion">
        <button
          type="button"
          className="btn ghost"
          onClick={() => scrollToLandingSection("landing-inscription", reducedMotion)}
        >
          Inscription
        </button>
        <button
          type="button"
          className="btn ghost"
          onClick={() => scrollToLandingSection("landing-connexion", reducedMotion)}
        >
          Connexion
        </button>
      </nav>
      <header className="hero">
        <div className="landing-settings-row">
          <GlobalSettingsMenu appearance={appearance} onUpdateAppearance={onUpdateAppearance} />
        </div>
        <div className="brand large">
          <UniFreshLogo />
          <div>
            <h1>UniFresh</h1>
            <p className="tagline">
              Nettoyage pour étudiants, entreprises et particuliers — une seule plateforme.
            </p>
          </div>
        </div>
        <p className="lead">
          Deux parcours clairs: un pour les étudiant·es qui veulent travailler sereinement, un pour
          les entreprises qui veulent un service fiable sans perdre de temps.
        </p>
      </header>

      <div className="split">
        <section className="card pitch">
          <h2>Pourquoi UniFresh ?</h2>
          <h3>Pour les étudiant·es</h3>
          <p>
            Trouvez des missions adaptées à votre rythme d’études, sans stress ni démarches
            compliquées. Votre profil est étudié rapidement et l’agence vous contacte pour proposer
            des créneaux compatibles avec vos cours.
          </p>
          <h3>Pour les entreprises et particuliers</h3>
          <p>
            Gagnez du temps: vous décrivez votre besoin une seule fois, puis UniFresh vous recontacte
            avec une solution claire. Vous bénéficiez d’un suivi humain, d’intervenants motivés et
            d’une organisation fiable.
          </p>
        </section>

        <section id="landing-inscription" className="card form-card">
          <h2>Inscription</h2>
          <form onSubmit={submit} className="form" noValidate>
            {error ? (
              <div className="alert" role="alert">
                {error}
              </div>
            ) : null}

            <fieldset className="profil-fieldset">
              <legend>Vous êtes</legend>
              <div className="profil-options">
                <label className={`profil-option ${profilType === "etudiant" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="profil"
                    value="etudiant"
                    checked={profilType === "etudiant"}
                    onChange={() => {
                      setProfilType("etudiant");
                    }}
                  />
                  <span className="profil-option-title">Étudiant·e</span>
                  <span className="profil-option-desc">Missions à côté des cours</span>
                </label>
                <label className={`profil-option ${profilType === "entreprise" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="profil"
                    value="entreprise"
                    checked={profilType === "entreprise"}
                    onChange={() => {
                      setProfilType("entreprise");
                      setPrenom("");
                      setAge("");
                      setCanton("");
                      setEcole("");
                    }}
                  />
                  <span className="profil-option-title">Entreprise</span>
                  <span className="profil-option-desc">Demander un service de nettoyage</span>
                </label>
                <label className={`profil-option ${profilType === "particulier" ? "selected" : ""}`}>
                  <input
                    type="radio"
                    name="profil"
                    value="particulier"
                    checked={profilType === "particulier"}
                    onChange={() => {
                      setProfilType("particulier");
                      setAge("");
                      setCanton("");
                      setEcole("");
                    }}
                  />
                  <span className="profil-option-title">Particulier</span>
                  <span className="profil-option-desc">Besoin à la maison</span>
                </label>
              </div>
            </fieldset>

            <label>
              <span>E-mail</span>
              <input
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="vous@exemple.fr"
              />
            </label>
            {profilType !== "entreprise" ? (
              <label>
                <span>Prénom</span>
                <input
                  type="text"
                  autoComplete="given-name"
                  value={prenom}
                  onChange={(e) => setPrenom(e.target.value)}
                  placeholder="Jean"
                />
              </label>
            ) : null}
            <label>
              <span>
                {profilType === "entreprise" ? "Raison sociale ou nom de l’entreprise" : "Nom"}
              </span>
              <input
                type="text"
                autoComplete={profilType === "entreprise" ? "organization" : "family-name"}
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                placeholder={
                  profilType === "entreprise" ? "SARL Exemple Nettoyage" : "Dupont"
                }
              />
            </label>
            {profilType === "etudiant" ? (
              <label>
                <span>Âge</span>
                <input
                  type="number"
                  inputMode="numeric"
                  min={16}
                  max={110}
                  autoComplete="off"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="20"
                />
              </label>
            ) : null}
            {profilType === "etudiant" ? (
              <label>
                <span>Canton</span>
                <select
                  value={canton}
                  onChange={(e) => setCanton(e.target.value)}
                  autoComplete="address-level1"
                >
                  <option value="">Choisissez votre canton</option>
                  {SWISS_CANTONS.map((c) => (
                    <option key={c.value} value={c.value}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </label>
            ) : null}
            {profilType === "etudiant" ? (
              <label>
                <span>École ou établissement</span>
                <input
                  type="text"
                  autoComplete="organization"
                  value={ecole}
                  onChange={(e) => setEcole(e.target.value)}
                  placeholder="Ex. : Gymnase de Nyon, EPFL, HES-SO…"
                />
              </label>
            ) : null}
            <label>
              <span>Téléphone</span>
              <input
                type="tel"
                autoComplete="tel"
                value={telephone}
                onChange={(e) => setTelephone(e.target.value)}
                placeholder="06 12 34 56 78"
              />
            </label>
            <button type="submit" className="btn primary" disabled={isSubmitting}>
              {isSubmitting ? "Envoi en cours..." : "Relire mon inscription"}
            </button>
          </form>
          {reviewRegistration ? (
            <section className="card" aria-live="polite">
              <h3>Relecture de votre inscription</h3>
              <p className="hint">Vérifiez chaque point avant d'envoyer le code de confirmation.</p>
              <div className="form">
                <p className="review-line">
                  <strong>Profil:</strong> {PROFIL_LABELS[reviewRegistration.profilType]}
                </p>
                <p className="review-line">
                  <strong>E-mail:</strong> {reviewRegistration.email}
                </p>
                {reviewRegistration.prenom ? (
                  <p className="review-line">
                    <strong>Prénom:</strong> {reviewRegistration.prenom}
                  </p>
                ) : null}
                <p className="review-line">
                  <strong>Nom:</strong> {reviewRegistration.nom}
                </p>
                <p className="review-line">
                  <strong>Téléphone:</strong> {reviewRegistration.telephone}
                </p>
                {reviewRegistration.age != null ? (
                  <p className="review-line">
                    <strong>Âge:</strong> {String(reviewRegistration.age)}
                  </p>
                ) : null}
                {reviewRegistration.canton ? (
                  <p className="review-line">
                    <strong>Canton:</strong> {SWISS_CANTONS.find((c) => c.value === reviewRegistration.canton)?.label ?? reviewRegistration.canton}
                  </p>
                ) : null}
                {reviewRegistration.ecole ? (
                  <p className="review-line">
                    <strong>Établissement:</strong> {reviewRegistration.ecole}
                  </p>
                ) : null}
                <div className="slot-mode-tabs">
                  <button type="button" className="btn ghost" onClick={() => setReviewRegistration(null)}>
                    Modifier
                  </button>
                  <button
                    type="button"
                    className="btn primary"
                    disabled={isSubmitting}
                    onClick={() => sendRegistrationCode(reviewRegistration)}
                  >
                    {isSubmitting ? "Envoi en cours..." : "Valider et envoyer le code"}
                  </button>
                </div>
              </div>
            </section>
          ) : null}
          {pendingRegistration ? (
            <form onSubmit={submitConfirmation} className="form" noValidate>
              {confirmInfo ? (
                <div className="success-banner" role="status">
                  {confirmInfo}
                </div>
              ) : null}
              <p className="hint">
                Pensez à vérifier vos spams / courriers indésirables : le code de confirmation y
                apparaît parfois.
              </p>
              {confirmError ? (
                <div className="alert" role="alert">
                  {confirmError}
                </div>
              ) : null}
              <label>
                <span>Code de confirmation</span>
                <input
                  type="text"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  value={confirmationCode}
                  onChange={(e) => setConfirmationCode(e.target.value)}
                  placeholder="Ex. : 123456"
                />
              </label>
              <button type="submit" className="btn primary" disabled={isSubmitting}>
                {isSubmitting ? "Verification..." : "Valider mon inscription"}
              </button>
            </form>
          ) : null}
          <hr />
          <div id="landing-connexion" className="landing-connexion">
            <h3>Déjà inscrit·e ?</h3>
          <form onSubmit={submitLogin} className="form" noValidate>
            {loginError ? (
              <div className="alert" role="alert">
                {loginError}
              </div>
            ) : null}
            {loginInfo ? (
              <div className="success-banner" role="status">
                {loginInfo}
              </div>
            ) : null}
            <label>
              <span>E-mail de connexion</span>
              <input
                type="email"
                autoComplete="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="vous@exemple.fr"
              />
            </label>
            <button type="submit" className="btn ghost" disabled={isLoginSubmitting}>
              {isLoginSubmitting ? "Envoi..." : "Envoyer le code de connexion"}
            </button>
          </form>
          {pendingLoginEmail ? (
            <form onSubmit={submitLoginCode} className="form" noValidate>
              <p className="hint">
                Entrez le code reçu pour <strong>{pendingLoginEmail}</strong>.
              </p>
              <label>
                <span>Code de connexion</span>
                <input
                  type="text"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  value={loginCode}
                  onChange={(e) => setLoginCode(e.target.value)}
                  placeholder="Ex. : 123456"
                />
              </label>
              <button type="submit" className="btn primary" disabled={isLoginSubmitting}>
                {isLoginSubmitting ? "Verification..." : "Valider et se connecter"}
              </button>
            </form>
          ) : null}
          <button type="button" className="btn ghost" onClick={onOpenAdmin}>
            Accès demandes (admin)
            {adminUnseenCount > 0 ? (
              <span className="admin-unseen-pill">
                {adminUnseenCount} non lue{adminUnseenCount > 1 ? "s" : ""}
              </span>
            ) : null}
          </button>
          </div>
        </section>
      </div>

      <footer className="foot">
        <p>UniFresh · étudiants, entreprises & particuliers</p>
        <p>
          Site sécurisé · Contact: <a href="mailto:unifreshbynk@gmail.com">unifreshbynk@gmail.com</a>
        </p>
      </footer>
      <AiAdvisorWidget />
    </div>
  );
}
